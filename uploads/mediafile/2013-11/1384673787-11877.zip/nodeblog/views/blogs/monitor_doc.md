monitor 项目说明
==============

部署环境
----    
----
1. JDK:	1.6_x 最好采用最新版本的JDK
2. Tomcat: 6.x	请不要使用tomcat5.5的安装版
3. 数据库:	支持SQL Server和Oracle, 如果需要切换数据库请看后面部分: _更换数据库环境_
	+ __SQLServer__:	修改oracleDriver_mssql2005.properties 中的配置
	+ __Oracle__:	修改oracleDriver.properties 中的配置 

环境变量
----
---- 
部署环境需要确保配置了如下环境变量，有些工具需要使用到这些变量		

1. __JAVA_HOME__:	指向java安装还击那个
2. __CATALINA_HOME__:	指向tomcat安装目录	


配置项说明
-----
----- 
所有配置文件都在WEB-INF/classes/config目录下	

1. __oracleDriver*.properties__:	数据库配置文件, _mssql2005结尾的是sql server的配置
2. __param.properties__:	配置程序参数, 
	* __dyul30webservice.uri__	用于配置DYULC30WebService网络路径
	* 其他保持默认即可
3. __netmanage_url.properties__:	监控项目的网管配置
	* __netmanae.version__	配置网管的版本, 0:表示不使用网管, 2/3: 分别代表2.0网管/3.0网管
		* __0__		表示不使用网管, 程序只记录用户输入的用户名，不做任何验证工作.
		* __2__		表示采用2.0网管
		* __3__		表示采用3.0网管, 3.0网管需要部署netmanage3-rest项目
	* __rest.netmanage3.uri__	配置网管项目的访问路径，如果netmanage.version=3，则程序会读取这个值	


更换数据库环境
-------
---
打开 WEB-INFO/classes/spring/applicationContext.xml 文件, 找到如下代码段	

	<bean id="propertyConfigurer" class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer">
	<property name="locations">
		<list>
			<value>/WEB-INF/classes/config/oracleDriver_mssql2005.properties</value>
			<value>/WEB-INF/classes/config/param.properties</value>				
			<value>/WEB-INF/classes/config/netmanage_url.properties</value>				
		</list>
	</property>
	</bean>		

其中	
  
	<value>/WEB-INF/classes/config/oracleDriver_mssql2005.properties</value>	

表示的是sqlserver数据库，如果要换成Oracle，修改成:	

	<value>/WEB-INF/classes/config/oracleDriver.properties</value>	
	
	
