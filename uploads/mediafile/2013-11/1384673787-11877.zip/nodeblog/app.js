
/**
 * Module dependencies.
 */
require.paths.unshift('./mode_modules'); 
var express = require('express');
var markdown = require('markdown-js');

var app = module.exports = express.createServer();


// Configuration

app.configure(function(){
  app.set('views', __dirname + '/views');
  app.set('view engine', 'jade');
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(app.router);
  app.use(express.static(__dirname + '/public'));
});

app.configure('development', function(){
  app.use(express.errorHandler({ dumpExceptions: true, showStack: true })); 
});

app.configure('production', function(){
  app.use(express.errorHandler()); 
});

app.register('.md', {
  compile: function(str, options){
    var html = markdown.makeHtml(str);
    return function(locals){
      return html.replace(/\{([^}]+)\}/g, function(_, name){
        return locals[name];
      });
    };
  }
});

var config = {
    title: 'NodeBlog',
    author: 'lvjian'
}

// Routes

app.get('/', function(req, res){
  res.render('index', {
    title: config.title + ' - ' + config.author
  });
});

app.get('/markdown', function(req, res) {
    res.render('index.md', {layout: false});
})

app.get('/blogs/:title.html', function(req, res, next) {
    var path = [
        'blogs/',
        req.params.title, '.md'
    ].join('');
    
    console.log(path)
    res.render(path, {layout: false});
})

app.listen(process.env.VMC_APP_PORT || 3000);  
console.log("Express server listening on port %d in %s mode", app.address().port, app.settings.env);
